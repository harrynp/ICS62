Name: Harry Pham 79422112
TITLE: Space Battle
TAGLINE: Fight battles in space!
CONTROLS: Either click a mouse on the screen to shoot in that direction if on a computer or touch a spot on 
		  the screen if playing on an Android device 
PERSONAL GOALS: My personal goal for this project is to create a simple game that can be played on a computer 
				or an Android device.  I would use the knowledge I have gained from creating this project to 
				make future applications for computers and Android devices in the future.  I chose these 
				formats because I was interested in making apps for the formats I have chosen in the future.
TECH SPECS: Uses Processing 1.5.1 for Windows, Linux, and Mac exporting and Processing 2.0b9 for Android
			OS: Windows 8 Pro
			Tested only using emulator

This game uses the following sound effects:
�Blast Sound� by Mike Koenig, available under a Creative Commons Attribution license.
"Laser Cannon Sound" by Mike Koenig, available under a Creative Commons Attribution license.
Blast Sound gotten from http://soundbible.com/538-Blast.html.
Laswer Cannon Sound gotten from http://soundbible.com/1771-Laser-Cannon.html.
Fonts gotten from http://www.1001fonts.com/halo3-font.html


