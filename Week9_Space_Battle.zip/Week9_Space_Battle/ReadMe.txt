Harry Pham 79422112
1. TITLE: The title of my project is Space Battle.  I chose this title because the ship in the game is fighting enemies in space.
2. TOPIC: The topic of my project is about battles in space.
3. FIVE YEAR / CAREER GOAL: In five years, I would like my job title to be graduate student.
4. ARGUMENT: My main point in my project is to create a simple game that can be played.
5. STORY: My project is about battles in space.
6. GAMEPLAY: I communicate my argument and story by leaving debris when ships or asteroids get destroyed.
7. FUTURE DEVELOPMENT: Things that are not yet completed in my project include: Allowing player ship to move and 
accelerate, movement other than circling for the enemy ship, making asteroids bounce off screen instead of removing them
instead of adding more asteroids to increase difficulty, fix background picture to fit in the game more
Dear Blizzard,

Enclosed is a .zip archive of a game I've recently developed, titled Space Battle.  This project is about battles in space 
and the main point of it is to create a simple game. The project is about shooting objects as they approach the ship.
My career goal is to to become a programmer and this project highlights my experience in this field through the gameplay of defending
the ship.  I look forward to working with you and making a strong contribution to your team.
Sincerely,
Harry Pham

 
Changes in this version:
Commented out minim because it isn't supported in Android

This game uses the following sound effects:
�Blast Sound� by Mike Koenig, available under a Creative Commons Attribution license.
"Laser Cannon Sound" by Mike Koenig, available under a Creative Commons Attribution license.
Blast Sound gotten from http://soundbible.com/538-Blast.html.
Laswer Cannon Sound gotten from http://soundbible.com/1771-Laser-Cannon.html.
Fonts gotten from http://www.1001fonts.com/halo3-font.html



